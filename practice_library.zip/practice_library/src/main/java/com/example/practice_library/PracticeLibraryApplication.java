package com.example.practice_library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeLibraryApplication.class, args);
	}

}
