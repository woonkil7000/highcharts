package com.example.practice_library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
